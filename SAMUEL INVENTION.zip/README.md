# inventory-management
This is a inventory management system
